import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { motion, useScroll, useSpring } from 'framer-motion'
import {
  ArrowDownRight, ArrowUpRight, Github, Linkedin, Mail, Menu, X,
  Terminal, Code2, ShieldCheck, Layers3, MoveUpRight, Sparkles, Globe,
  Send, Check, MousePointer2
} from 'lucide-react'
import './styles.css'

const projects = [
  {
    n: '01', type: 'FULL-STACK / EXPERIMENT',
    title: 'NEXUS DASHBOARD',
    desc: 'A clean command center concept for turning messy data into clear next steps.',
    tags: ['React', 'UI systems', 'API-ready'],
    art: 'nexus', link: 'https://github.com/'
  },
  {
    n: '02', type: 'BACKEND / GO',
    title: 'GO REST LAB',
    desc: 'A learning project exploring REST endpoints, request handling, and dependable backend structure.',
    tags: ['Go', 'REST API', 'JSON'],
    art: 'terminal', link: 'https://github.com/'
  },
  {
    n: '03', type: 'WEB / COMMERCE',
    title: 'XEVRA STUDIO',
    desc: 'A minimal storefront direction for modern modest menswear with a strong editorial feel.',
    tags: ['HTML/CSS', 'JavaScript', 'Branding'],
    art: 'fashion', link: 'https://github.com/'
  }
]

const skills = [
  { name: 'FRONTEND', detail: 'React · JavaScript · HTML · CSS', icon: Code2, level: 'BUILDING' },
  { name: 'BACKEND', detail: 'Go · REST APIs · JSON · HTTP', icon: Terminal, level: 'LEARNING' },
  { name: 'SECURITY', detail: 'Linux · Networking · Security fundamentals', icon: ShieldCheck, level: 'EXPLORING' },
  { name: 'DESIGN', detail: 'Visual systems · Responsive UI · Motion', icon: Layers3, level: 'PRACTICING' }
]

function Reveal({ children, delay = 0, className = '' }) {
  return <motion.div className={className} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.15 }} transition={{ duration: .7, delay, ease: [0.22, 1, 0.36, 1] }}>{children}</motion.div>
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const [clock, setClock] = useState('')
  const { scrollYProgress } = useScroll()
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 })

  useEffect(() => {
    const update = () => setClock(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Tashkent' }).format(new Date()))
    update()
    const id = setInterval(update, 30000)
    return () => clearInterval(id)
  }, [])

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText('hello@firdavs.dev')
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    } catch {
      window.location.href = 'mailto:hello@firdavs.dev'
    }
  }

  const closeMenu = () => setMenuOpen(false)

  return (
    <>
      <motion.div className="progress-line" style={{ scaleX }} />
      <div className="grain" aria-hidden="true" />
      <header className="topbar">
        <a className="brand" href="#home" onClick={closeMenu} aria-label="Firdavs home">
          <span className="brand-mark">F<span>.</span></span><span className="brand-name">FIRDAVS<sup>®</sup></span>
        </a>
        <div className="nav-right">
          <span className="local-time"><span className="live-dot" /> TASHKENT&nbsp; {clock || '—'}</span>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'}>{menuOpen ? <X size={19}/> : <Menu size={19}/>}</button>
        </div>
        <nav className={menuOpen ? 'nav-links open' : 'nav-links'}>
          {[['Work','#work'],['About','#about'],['Stack','#stack'],['Contact','#contact']].map(([label, href]) =>
            <a key={label} href={href} onClick={closeMenu}>{label}<ArrowUpRight size={12}/></a>
          )}
        </nav>
      </header>

      <main id="home">
        <section className="hero section-shell">
          <div className="hero-meta mono"><span>INDEPENDENT DEVELOPER</span><span>AVAILABLE FOR SELECT PROJECTS <i className="status-dot"/></span></div>
          <div className="hero-main">
            <div className="hero-copy">
              <Reveal>
                <p className="eyebrow"><span className="eyebrow-line"/> DIGITAL CRAFT / 2026</p>
                <h1>MAKE IT<br/><span className="outline-text">MEAN</span><span className="lime-period">.</span></h1>
              </Reveal>
              <Reveal delay={.12}>
                <div className="hero-bottom">
                  <p className="hero-intro">I'm Firdavs — a developer in progress, turning curiosity into useful digital experiences. I build interfaces, explore backend systems, and care about the details.</p>
                  <a href="#work" className="round-link" aria-label="Explore selected work"><ArrowDownRight size={26}/></a>
                </div>
              </Reveal>
            </div>
            <motion.div className="orbital-stage" initial={{ opacity: 0, scale: .8, rotate: -12 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} transition={{ duration: 1.1, ease: [.16, 1, .3, 1], delay: .15 }}>
              <div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit orbit-three"/>
              <div className="orb-core"><span>F</span><i/></div>
              <div className="orbit-label label-top mono">IDEAS → INTERFACES</div>
              <div className="orbit-label label-bottom mono">CODE WITH INTENT</div>
              <motion.div className="float-chip chip-code" animate={{ y: [0,-9,0], rotate: [0,3,0] }} transition={{ repeat: Infinity, duration: 5, ease: 'easeInOut' }}><Code2 size={16}/><span>build()</span></motion.div>
              <motion.div className="float-chip chip-shield" animate={{ y: [0,8,0], rotate: [0,-4,0] }} transition={{ repeat: Infinity, duration: 4.2, ease: 'easeInOut' }}><ShieldCheck size={17}/><span>think secure</span></motion.div>
              <div className="orbit-cross cross-a">+</div><div className="orbit-cross cross-b">✳</div>
            </motion.div>
          </div>
          <div className="hero-foot mono"><span>SCROLL TO EXPLORE <MousePointer2 size={13}/></span><span>41°18' N — 69°16' E</span><span>PORTFOLIO / 001</span></div>
        </section>

        <div className="marquee" aria-label="Design, develop, iterate">
          <div className="marquee-track">{Array.from({length: 4}).map((_,i)=><span key={i}>DESIGN WITH PURPOSE <b>✳</b> DEVELOP WITH CURIOSITY <b>✳</b> ITERATE ALWAYS <b>✳</b></span>)}</div>
        </div>

        <section id="work" className="work section-shell section-pad">
          <Reveal className="section-heading">
            <div><p className="eyebrow"><span className="eyebrow-line"/> 01 / SELECTED WORK</p><h2>Proof of <span className="serif-word">practice.</span></h2></div>
            <p className="section-note">A few things I've built, explored, or am actively shaping. Every project is a chance to get sharper.</p>
          </Reveal>
          <div className="project-list">
            {projects.map((p, i) => <Reveal key={p.n} delay={i * .08}>
              <article className="project-row">
                <div className="project-number mono">{p.n}<span> / 03</span></div>
                <a className={`project-art ${p.art}`} href={p.link} target="_blank" rel="noreferrer" aria-label={`Open ${p.title} on GitHub`}>
                  {p.art === 'nexus' && <div className="nexus-art"><div className="nexus-ring ring-a"/><div className="nexus-ring ring-b"/><div className="nexus-card"><span>OVERVIEW</span><b>+24.8%</b><small>GROWTH THIS MONTH</small><div className="mini-bars">{[28,44,35,58,47,76,62,92,68,83].map((v,j)=><i key={j} style={{height:`${v}%`}}/>)}</div></div><span className="art-cross">✳</span></div>}
                  {p.art === 'terminal' && <div className="terminal-art"><div className="terminal-top"><i/><i/><i/><span>main.go</span></div><div className="terminal-code"><p><em>package</em> main</p><p><em>import</em> <b>"net/http"</b></p><br/><p><strong>func</strong> <u>main</u>() {'{'}</p><p>&nbsp;&nbsp;http.<u>HandleFunc</u>(<b>"/"</b>, handler)</p><p>&nbsp;&nbsp;http.<u>ListenAndServe</u>(<b>":8080"</b>, nil)</p><p>{'}'}</p><span className="terminal-cursor">▋</span></div></div>}
                  {p.art === 'fashion' && <div className="fashion-art"><span className="fashion-label">XEVRA® / FORM STUDY</span><div className="fashion-sun"/><div className="fashion-silhouette"><i/><b/><span/></div><strong>LESS<br/>BUT<br/><em>BETTER.</em></strong><div className="fashion-bottom">MODERN · MINIMAL · MODEST</div></div>}
                  <span className="art-open"><ArrowUpRight size={19}/></span>
                </a>
                <div className="project-info"><div className="project-type mono">{p.type}</div><h3>{p.title}</h3><p>{p.desc}</p><div className="tag-row">{p.tags.map(t=><span key={t}>{t}</span>)}</div></div>
                <a className="project-arrow" href={p.link} target="_blank" rel="noreferrer" aria-label={`Visit ${p.title}`}><MoveUpRight size={22}/></a>
              </article>
            </Reveal>)}
          </div>
          <div className="work-foot mono"><span>MORE EXPERIMENTS IN PROGRESS</span><a href="https://github.com/" target="_blank" rel="noreferrer">VIEW GITHUB <ArrowUpRight size={13}/></a></div>
        </section>

        <section id="about" className="about-section">
          <div className="section-shell section-pad">
            <Reveal className="section-heading">
              <div><p className="eyebrow"><span className="eyebrow-line"/> 02 / THE PERSON</p><h2>Curious by<br/>default<span className="lime-period">.</span></h2></div>
              <div className="about-statement"><span className="big-quote">“</span><p>I don't want to just make things that look good. I want to understand <em>why they work</em> — from the first pixel to the last request.</p></div>
            </Reveal>
            <div className="about-grid">
              <Reveal className="about-card about-card-main">
                <div className="about-card-top mono"><span>THE SHORT VERSION</span><Sparkles size={16}/></div>
                <p>I'm learning to connect <span className="highlight">thoughtful design</span> with <span className="highlight">reliable code</span>. Right now, that means sharpening my React skills, building with Go, and getting deeper into Linux and security fundamentals.</p>
                <div className="about-stamp"><span>STAY<br/>CURIOUS</span><Globe size={21}/></div>
              </Reveal>
              <Reveal delay={.1} className="about-card facts-card">
                <div className="about-card-top mono"><span>WORKING PRINCIPLES</span><span>03 ITEMS</span></div>
                {[['01','Make it clear','Good experiences feel effortless.'],['02','Keep learning','Every build should teach me something.'],['03','Stay honest','Show the work. Respect the process.']].map(([n,t,d])=><div className="principle" key={n}><span className="mono">{n}</span><div><b>{t}</b><p>{d}</p></div><ArrowUpRight size={15}/></div>)}
              </Reveal>
            </div>
          </div>
        </section>

        <section id="stack" className="stack-section section-shell section-pad">
          <Reveal className="section-heading">
            <div><p className="eyebrow"><span className="eyebrow-line"/> 03 / CURRENT TOOLKIT</p><h2>Learning in<br/><span className="serif-word">public.</span></h2></div>
            <p className="section-note">Skills are a practice, not a trophy shelf. Here's what I'm working with and where I'm putting in the reps.</p>
          </Reveal>
          <div className="skill-grid">
            {skills.map((s,i)=><Reveal delay={i*.06} key={s.name}><div className="skill-card"><div className="skill-top"><s.icon size={22} strokeWidth={1.5}/><span className="mono">{s.level}</span></div><h3>{s.name}</h3><p>{s.detail}</p><div className="skill-index mono">0{i+1} <span>— 04</span></div></div></Reveal>)}
          </div>
          <Reveal className="learning-strip"><div className="learning-icon"><Terminal size={20}/></div><div><span className="mono">CURRENTLY DEEPENING</span><b>React patterns · Go backend fundamentals · American English</b></div><span className="learning-spark">✳</span></Reveal>
        </section>

        <section id="contact" className="contact-section">
          <div className="section-shell contact-inner">
            <Reveal>
              <p className="eyebrow"><span className="eyebrow-line"/> 04 / YOUR TURN</p>
              <h2>Have a good<br/>one in <span className="serif-word">mind?</span></h2>
              <p className="contact-desc">Have an idea, a collaboration, or just want to talk code? My inbox is open.</p>
              <button className="contact-cta" onClick={copyEmail}><span>{copied ? 'EMAIL COPIED' : 'LET’S TALK'}</span><span className="cta-icon">{copied ? <Check size={21}/> : <ArrowUpRight size={21}/>}</span></button>
            </Reveal>
            <div className="contact-side">
              <div className="contact-orbit"><div className="contact-orbit-inner">F<span>.</span></div><span className="contact-orbit-word">OPEN TO GOOD IDEAS</span></div>
              <div className="social-list mono">
                <a href="https://github.com/" target="_blank" rel="noreferrer"><Github size={16}/> GITHUB <ArrowUpRight size={13}/></a>
                <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer"><Linkedin size={16}/> LINKEDIN <ArrowUpRight size={13}/></a>
                <a href="mailto:hello@firdavs.dev"><Mail size={16}/> EMAIL <ArrowUpRight size={13}/></a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer section-shell">
        <a className="brand" href="#home"><span className="brand-mark">F<span>.</span></span><span className="brand-name">FIRDAVS<sup>®</sup></span></a>
        <span className="footer-center mono">DESIGNED WITH INTENT. BUILT WITH CURIOSITY.</span>
        <a href="#home" className="back-top mono">BACK TO TOP ↑</a>
        <span className="copyright mono">© 2026 FIRDAVS. STILL LEARNING.</span>
      </footer>
    </>
  )
}

createRoot(document.getElementById('root')).render(<App />)
